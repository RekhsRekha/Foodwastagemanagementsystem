SELECT TOP 1
    p.Provider_ID,
    p.Name AS Provider_Name,
    p.Type AS Provider_Type,
    COUNT(c.Claim_ID) AS Successful_Claims_Count
FROM Providers p
JOIN FoodListings f ON p.Provider_ID = f.Provider_ID
JOIN Claims c ON f.Food_ID = c.Food_ID
WHERE c.Status = 'Completed'
GROUP BY p.Provider_ID, p.Name, p.Type
ORDER BY Successful_Claims_Count DESC;