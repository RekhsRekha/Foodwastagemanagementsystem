SELECT 
    p.Provider_ID,
    p.Name AS Provider_Name,
    p.Type AS Provider_Type,
    ISNULL(SUM(f.Quantity), 0) AS Total_Quantity_Donated
FROM Providers p
LEFT JOIN FoodListings f ON p.Provider_ID = f.Provider_ID
GROUP BY p.Provider_ID, p.Name, p.Type
ORDER BY Total_Quantity_Donated DESC;