SELECT TOP 1
    Location AS City, 
    COUNT(Food_ID) AS Total_Listings,
    SUM(Quantity) AS Total_Quantity
FROM FoodListings
GROUP BY Location
ORDER BY Total_Listings DESC;