SELECT 
    r.Receiver_ID,
    r.Name AS Receiver_Name,
    AVG(CAST(f.Quantity AS DECIMAL(10,2))) AS Avg_Quantity_Claimed
FROM Receivers r
JOIN Claims c ON r.Receiver_ID = c.Receiver_ID
JOIN FoodListings f ON c.Food_ID = f.Food_ID
GROUP BY r.Receiver_ID, r.Name
ORDER BY Avg_Quantity_Claimed DESC;