SELECT TOP 10
    r.Name AS Receiver_Name,
    r.Type AS Receiver_Type,
    COUNT(c.Claim_ID) AS Total_Claims_Made
FROM Receivers r
JOIN Claims c ON r.Receiver_ID = c.Receiver_ID
GROUP BY r.Name, r.Type
ORDER BY Total_Claims_Made DESC;