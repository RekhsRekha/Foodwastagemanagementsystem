SELECT 
    ISNULL(p.City, r.City) AS City,
    COUNT(DISTINCT p.Provider_ID) AS Total_Providers,
    COUNT(DISTINCT r.Receiver_ID) AS Total_Receivers
FROM Providers p
FULL OUTER JOIN Receivers r ON p.City = r.City
GROUP BY ISNULL(p.City, r.City)
ORDER BY City;