SELECT Location AS City, Meal_Type, SUM(Quantity) AS Distributed_Volume
FROM FoodListings
GROUP BY Location, Meal_Type
ORDER BY Location, Distributed_Volume DESC;