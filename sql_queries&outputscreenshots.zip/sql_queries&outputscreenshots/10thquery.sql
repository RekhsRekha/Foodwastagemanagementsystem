SELECT 
    Status, 
    COUNT(*) AS Total_Count, 
    CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Claims) AS DECIMAL(5,2)) AS Percentage
FROM Claims
GROUP BY Status;