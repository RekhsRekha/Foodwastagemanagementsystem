SELECT 
    Food_Type, 
    COUNT(*) AS Number_of_Listings, 
    SUM(Quantity) AS Total_Quantity
FROM FoodListings
GROUP BY Food_Type
ORDER BY Number_of_Listings DESC;