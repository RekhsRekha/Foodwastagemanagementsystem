SELECT 
    f.Food_ID,
    f.Food_Name,
    f.Food_Type,
    COUNT(c.Claim_ID) AS Claims_Count
FROM FoodListings f
LEFT JOIN Claims c ON f.Food_ID = c.Food_ID
GROUP BY f.Food_ID, f.Food_Name, f.Food_Type
ORDER BY Claims_Count DESC;