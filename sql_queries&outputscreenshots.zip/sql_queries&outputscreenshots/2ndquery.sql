SELECT 
    Provider_Type, 
    SUM(Quantity) AS Total_Food_Contributed
FROM FoodListings
GROUP BY Provider_Type
ORDER BY Total_Food_Contributed DESC;