SELECT Food_Name, Quantity, Expiry_Date, Location 
FROM FoodListings 
WHERE Expiry_Date BETWEEN GETDATE() AND DATEADD(day, 3, GETDATE())
ORDER BY Expiry_Date ASC;