SELECT 
    Name, 
    Type AS Provider_Type, 
    Contact, 
    Address
FROM Providers
WHERE City = 'Adamsville'  
ORDER BY Name;