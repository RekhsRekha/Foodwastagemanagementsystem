SELECT 
    f.Meal_Type, 
    COUNT(c.Claim_ID) AS Total_Claims
FROM FoodListings f
JOIN Claims c ON f.Food_ID = c.Food_ID
GROUP BY f.Meal_Type
ORDER BY Total_Claims DESC;