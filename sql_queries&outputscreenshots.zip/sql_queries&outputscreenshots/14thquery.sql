-- Part A: Registered Providers with Zero Listings Created
SELECT 
    p.Provider_ID, 
    p.Name AS Provider_Name, 
    p.Type AS Provider_Type, 
    p.City
FROM Providers p
LEFT JOIN FoodListings f ON p.Provider_ID = f.Provider_ID
WHERE f.Food_ID IS NULL
ORDER BY p.Name;

-- Part B: Registered Receivers with Zero Claims Placed
SELECT 
    r.Receiver_ID, 
    r.Name AS Receiver_Name, 
    r.Type AS Receiver_Type, 
    r.City
FROM Receivers r
LEFT JOIN Claims c ON r.Receiver_ID = c.Receiver_ID
WHERE c.Claim_ID IS NULL
ORDER BY r.Name;