SELECT 
    f.Provider_Type,
    COUNT(c.Claim_ID) AS Total_Claims_Received,
    SUM(CASE WHEN c.Status = 'Completed' THEN 1 ELSE 0 END) AS Successful_Claims,
    SUM(CASE WHEN c.Status = 'Cancelled' THEN 1 ELSE 0 END) AS Cancelled_Claims,
    SUM(CASE WHEN c.Status = 'Pending' THEN 1 ELSE 0 END) AS Active_Pending_Claims,
    CAST(SUM(CASE WHEN c.Status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(c.Claim_ID), 0) AS DECIMAL(5,2)) AS Fulfillment_Success_Rate_Percentage
FROM FoodListings f
JOIN Claims c ON f.Food_ID = c.Food_ID
GROUP BY f.Provider_Type
ORDER BY Fulfillment_Success_Rate_Percentage DESC;